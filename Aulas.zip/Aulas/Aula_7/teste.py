def ola_mundo():
    print("Olá Mundo")


def e_primo():
    print("E primo")


def media():
    print("Media")

# Se esse arq só tem o nome __main__ quando é chamado diretamente
# Quando ele é chamdo por outro modulo ele passa a ter o nome do arquivo


if __name__ == "__main__":
    ola_mundo()
    media()
    e_primo()
    print(__name__)
