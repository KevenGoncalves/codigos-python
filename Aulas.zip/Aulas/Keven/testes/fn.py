import ..funcoes.teste as ts

ts.ola_mundo()
