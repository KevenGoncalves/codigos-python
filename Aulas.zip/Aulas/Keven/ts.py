import funcoes.teste

funcoes.teste.ola_mundo()
