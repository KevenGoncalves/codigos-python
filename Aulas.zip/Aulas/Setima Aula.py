# def ler_media():
#     media1 = int(input('Digita nota1: '))
#     media2 = int(input('Digita nota2: '))
#     media3 = int(input('Digita nota3: '))
#     media = ((media1+media2+media3)/3)

#     return media


# def verificar_media(media):
#     if media <= 9:
#         return 'Reprovou'
#     elif media <= 13:
#         return 'Passou'
#     else:
#         return 'Dispensou'


# while True:
#     media = ler_media()
#     estado = verificar_media(media)
#     print(media, estado)

#     while True:
#         c = str(input('Continuar/Fechar:  ')).upper()
#         if c in 'Continuar':
#             break
#         elif c in 'Fechar':
#             quit()

#         print('Erro! Digita apenas Continuar ou Fechar')
#         print('=' * 150)


# valores = input("Introduza os valores separados com ,:").split(",")
# map_em_inteiros = map(lambda valor: int(valor), valores)
# valores_em_inteiros = list(map_em_inteiros)
# map_de_cubos = map(lambda valor: valor ** 3, valores_em_inteiros)
# valores_em_cubos = list(map_de_cubos)


# lista = []

# for i in range(100):
#     if i % 2 != 0:
#         lista.append(i)


lista = [i for i in range(100) if i % 2 != 0]
print(lista)


