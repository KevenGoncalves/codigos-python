def teste():
    print("Olá Mundo")


if __name__ == "__main__":
    teste()
