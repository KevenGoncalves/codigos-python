# Aula 1

Linguagem Python

Linguagem Permite criar programs

2 tipos de Linguagem de Progamação:

- Linguagem de Baixo
- Linguagem de Alto - Python

Python 2
Python 3
