# import numpy as np

valorA = 10
valorB = 18
# media=(valorA+valorB)/2

# print(f"O {valorA} e {valorB} a media é {media}")

# primeira
# concatenação de strings

# repetição de strings
# 4
# "4"
# curioso
# print("keven "+"4")
# int()
# float()
# str()
# bool()

# Input '1'
# valorB = input("Qual é o valor")

# float '1' -> 1
# valorA = float(valorB)
# print("keven"+ str(media))

# print(f"keven {media}")

# se media > 10 entao:
#   imprima(passou)
# senao:
#   imprima (nao passou)

# if media > 10:
#     print("Passou")

#     if media > 15:
#         print("dispensou")

# else:
#     print("Nao passou")


# if media > 14:
#     print("dispensou")
# elif media > 10:
#     print("passou")
# elif media > 5:
#     print(" vai a recuperacao")
# else:
#     print("reprovou")


# if media > 14:
#     print("dispensou")
# if media > 10:
#     print("passou")
# if media > 5:
#     print("vai a recuperacao")
# else:
#     print("reprovou")
