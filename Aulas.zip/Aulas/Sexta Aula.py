a = [9, 2]
a = list(set(a))

# [x] chamada de função
# [x] retornos multiplos
# [x] multiplos argumentos
# [x] função lambda
# [x] operador ternario
# [x] troca de valores entre variaveis
# [x] operador de membros
# [x] type
# [x] pass
# map

# camelCase = oMeuNome, oMeuDado,nome,nomeCompleto => Java,JS
# pascalCase = OMeuNome, OMeuDado, Nome, NomeCompleto => C#
# snake_case = o_meu_nome, nome, nome_completo => C, C++, Python ,Rust
# ?? = o-meu-nome,nome, nome-completo => nomeclatura de pastas
# MACRO = O_MEU_NOME, NOME_COMPLETO


# def ler_nome_e_idade(**kargs):
#     idade = int(input("idade:"))
#     nome_completo = kargs["nome_completo"]

#     return nome_completo, idade


# novo_dado = ler_nome_e_idade(nome_completo="Keven")

# print(novo_dado)


# def calcular_media(nota1, nota2, nota3):
#     return (nota1 + nota2 + nota3)/3


# calcular_media = lambda n1, n2, n3: (n1+n2+n3)/3

# notas = input("Introduza 3 notas separadas com ,:").split(",")
# media = calcular_media(int(notas[0]), int(notas[1]), int(notas[2]))


# nome = "Keven" if notas[1] == 18 else "Goncalves"

# nota1 = 20
# nota2 = 15
# nota3 = 67


# nota1, nota2 = 50, 100

# print(nota1, nota2)

# lista = [1, 2, 3, "Keven", "Luis"]
# nome = "Keven"

# print(type(nome))

# # def verificar():
# #     return nome not in lista


# def verificar():
#     pass

# def verificar():
#     for valor in lista:
#         if valor == nome:
#             return True


entrada_em_string = input("Introduza valor com -")
lista_de_strings = entrada_em_string.split("-")
map_de_inteiros = map(lambda valor: int(valor), lista_de_strings)
lista_em_inteiros = list(map_de_inteiros)

print(lista_em_inteiros)
