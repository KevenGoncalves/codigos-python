# numero = 9
# variavel = "Keven"
# variavel = True | False

# Inteiros
# 9 10 20

# # Float Decimais
# 19.2 9.3

# # String
# "Keven"

# # Boolean Verdade e False
# True | False

# # None
# None

# # Imaginario
# 9i
# 9+j
variavelA = "Máquina"
# variavelA = 18

"""
Operadores Matematicos
+
-
*
/
//
%
**

Operadores de Comparação
==
!=
>
<
>=
<=

Operadores Logicos
and ==> e
or ==> ou
not ==> não

"""
NomeCompleto = "Keven Gonçalves"


valorA = 10
valorB = 20
valorC = valorA > valorB
# 10  * 20 == 200

print(valorC)

