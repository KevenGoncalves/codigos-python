def hello_word():
    print("Hello Word")


def meu_nome():
    pass
