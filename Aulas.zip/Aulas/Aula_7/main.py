# import teste

# teste.media()

# try:
#     pass
# except Exception as err:
#     pass
# finally:
#     pass

# [14,15,16]

# def media(lista):

#     total = 0

#     for valor in lista:
#         total += valor

#     return total/len(lista)


lista_em_string = input("Quais são as medias separadas por ,:").split(",")
map_em_inteiros = map(lambda x: int(x), lista_em_string)
lista_em_inteiros = list(map_em_inteiros)


def media(lista):
    return sum(lista)/len(lista)


print(media(lista_em_inteiros))

# def tamanho_lista(lista):

#     total = 0

#     for _ in lista:
#         total += 1

#     return total
