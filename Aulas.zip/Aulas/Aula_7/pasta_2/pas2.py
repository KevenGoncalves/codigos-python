from ..pasta_1 import pas1

pas1.meu_nome()
