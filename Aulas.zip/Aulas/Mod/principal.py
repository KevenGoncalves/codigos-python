# from funcoes import hello_word as hello_word_funcoes, meu_nome
# from secundaria import hello_word

# from funcoes import meu_nome
import funcoes as fn
# import secundaria as sd

# from funcoes import *
# from secundaria import *

fn.hello_word()
fn.meu_nome()

# fn.hello_word()
# sd.hello_word()
