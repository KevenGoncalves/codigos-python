# lista = []

# while True:
#     nome = input("Indtroduzir Nome:")
#     idade = input("Introduzir Idade:")

#     if nome == "exit" or idade == "exit":
#         break

#     lista.append({
#         "nome": nome,
#         "idade": int(idade)
#     })

# print(lista)

# numeros = []

# while True:
#     num = input("Introduza os numero:")

#     if num == "exit":
#         break

#     numeros.append(int(num))


# def organizar_lista(lista):
#     for i in range(len(lista)):
#         for j in range(i+1, len(lista)):
#             if lista[i] > lista[j]:
#                 lista[i], lista[j] = lista[j], lista[i]
#     return lista


# print(organizar_lista(numeros))

# print(f"{1}", end="")
# print("leven")
