def ola_mundo():
    pass
